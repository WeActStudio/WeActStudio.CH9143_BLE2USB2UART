//
//  SideMeunHeadView.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/4/6.
//

import UIKit

class SideMeunHeadView: UIView {

    @IBOutlet weak var headLabel: UILabel!
    
    override func awakeFromNib() {
        self.headLabel.layer.cornerRadius = 25
        self.headLabel.layer.masksToBounds = true
    }
}
