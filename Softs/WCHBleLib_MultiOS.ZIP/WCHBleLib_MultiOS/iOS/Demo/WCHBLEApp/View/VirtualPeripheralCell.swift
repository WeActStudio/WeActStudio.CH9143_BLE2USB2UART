//
//  VirtualPeripheralCell.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/4/6.
//

import UIKit

class VirtualPeripheralCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var serviceLabel: UILabel!


    @IBOutlet weak var checkIconImageView: UIImageView!
    
    private var didCheckImgClickAction: (() -> Void)?
    
    
    override func awakeFromNib() {
        checkIconImageView.isUserInteractionEnabled = true
        let tapRecognizeGesture = UITapGestureRecognizer(target: self, action: #selector(didCheckImgClick(_:)))
        checkIconImageView.addGestureRecognizer(tapRecognizeGesture)
    }
    
    func setDidCheckImgClickAction(_ action: @escaping (() -> Void)) {
        didCheckImgClickAction = action
    }
    
    @objc private func didCheckImgClick(_ sender: AnyObject) {
        guard let action = didCheckImgClickAction else {
            return
        }
        
        action()
    }
    
}
