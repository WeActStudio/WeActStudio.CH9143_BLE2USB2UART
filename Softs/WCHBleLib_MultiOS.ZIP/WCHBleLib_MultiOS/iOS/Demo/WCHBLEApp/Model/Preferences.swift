//
//  Preferences.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/4/2.
//

import Foundation

struct Preferences: Codable {
    var needFilter: Bool
    var filter: Int
    
    init() {
        self.needFilter = false
        filter = -90
    }
}

class PreferencesStore : NSObject {
    
    static let shared = PreferencesStore()
    private let preferencesKey = "preferencesKey"
    
    var preferences: Preferences? {
        didSet {
            self.save()
        }
    }
    
    override init() {
        if let data = UserDefaults.standard.object(forKey: preferencesKey) as? Data, let preferences = try? JSONDecoder().decode(Preferences.self, from: data) {
            self.preferences = preferences
        }
    }
    
    private func save() {
        guard let encodedData = try? JSONEncoder().encode(preferences) else {
            return
        }
        
        UserDefaults.standard.set(encodedData, forKey: preferencesKey)
        UserDefaults.standard.synchronize()
    }
}
