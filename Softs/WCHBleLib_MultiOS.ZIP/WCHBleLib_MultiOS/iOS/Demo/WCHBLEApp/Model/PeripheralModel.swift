//
//  PeripheralModel.swift
//  WCHBLEApp
//
//  Created by 娟华 胡 on 2021/3/16.
//

import UIKit
import CoreBluetooth

class PeripheralModel: Equatable, Hashable  {
    let peripheral:CBPeripheral
    var advertisementData:[String:Any] = [:]
    var RSSI:NSNumber = 0
    var lastUpdatedTimeInterval: TimeInterval
    
    init(_ peripheral: CBPeripheral) {
        self.peripheral = peripheral
        self.lastUpdatedTimeInterval = Date().timeIntervalSince1970
    }
    
    static func == (lhs: PeripheralModel, rhs: PeripheralModel) -> Bool {
        return lhs.peripheral.isEqual(rhs.peripheral)
    }
    
    func hash(into hasher: inout Hasher) {
        
    }
}
