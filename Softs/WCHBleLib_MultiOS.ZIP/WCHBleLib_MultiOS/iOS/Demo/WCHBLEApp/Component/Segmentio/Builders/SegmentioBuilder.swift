//
//  SegmentioBuilder.swift
//  Segmentio
//
//  Created by 娟华 胡 on 2021/3/16.
//

import UIKit

struct SegmentioBuilder {
    //添加角标
    static func setupBadgeCountForIndex(_ segmentioView: Segmentio, index: Int) {
        segmentioView.addBadge(
            at: index,
            count: 10,
            color: UIColor.black
        )
    }
    
//    static func buildSegmentioView(segmentioView: Segmentio, segmentioStyle: SegmentioStyle, segmentioPosition: SegmentioPosition = .fixed(maxVisibleItems: 3)) {
//        segmentioView.setup(
//            content: segmentioContent(),
//            style: segmentioStyle,
//            options: segmentioOptions(segmentioStyle: segmentioStyle, segmentioPosition: segmentioPosition)
//        )
//    }
//
//    private static func segmentioContent() -> [SegmentioItem] {
//        return [
//            SegmentioItem(title: "Tornado", image: UIImage(named: "tornado")),
//            SegmentioItem(title: "Earthquakes", image: UIImage(named: "earthquakes")),
//            SegmentioItem(title: "Extreme heat", image: UIImage(named: "heat")),
//            SegmentioItem(title: "Eruption", image: UIImage(named: "eruption")),
//            SegmentioItem(title: "Floods", image: UIImage(named: "floods")),
//            SegmentioItem(title: "Wildfires", image: UIImage(named: "wildfires"))
//        ]
//    }

    public static func segmentioOptions(segmentioStyle: SegmentioStyle, segmentioPosition: SegmentioPosition = .fixed(maxVisibleItems: 3)) -> SegmentioOptions {
        var imageContentMode = UIView.ContentMode.center
        switch segmentioStyle {
        case .imageBeforeLabel, .imageAfterLabel:
            imageContentMode = .scaleAspectFit
        default:
            break
        }
        
        return SegmentioOptions(
            backgroundColor: UIColor.white,
            segmentPosition: segmentioPosition,
            scrollEnabled: true,
            indicatorOptions: segmentioIndicatorOptions(),
            horizontalSeparatorOptions: segmentioHorizontalSeparatorOptions(),
            verticalSeparatorOptions: segmentioVerticalSeparatorOptions(),
            imageContentMode: imageContentMode,
            labelTextAlignment: .center,
            labelTextNumberOfLines: 1,
            segmentStates: segmentioStates(),
            animationDuration: 0.3
        )
    }
    
    private static func segmentioStates() -> SegmentioStates {
        let font = UIFont.systemFont(ofSize: 13)
        return SegmentioStates(
            defaultState: segmentioState(
                backgroundColor: .clear,
                titleFont: font,
                titleTextColor: UIColor.black.withAlphaComponent(0.4)
            ),
            selectedState: segmentioState(
                backgroundColor: .clear,
                titleFont: font,
                titleTextColor: UIColor.init(r: 42, g: 140, b: 205)
            ),
            highlightedState: segmentioState(
                backgroundColor: UIColor.clear,
                titleFont: font,
                titleTextColor: UIColor.clear
            )
        )
    }
    
    private static func segmentioState(backgroundColor: UIColor, titleFont: UIFont, titleTextColor: UIColor) -> SegmentioState {
        return SegmentioState(
            backgroundColor: backgroundColor,
            titleFont: titleFont,
            titleTextColor: titleTextColor
        )
    }
    
    private static func segmentioIndicatorOptions() -> SegmentioIndicatorOptions {
        return SegmentioIndicatorOptions(
            type: .bottom,
            ratio: 0.3,
            height: 2,
            color: UIColor.init(r: 42, g: 140, b: 205)
        )
    }
    
    private static func segmentioHorizontalSeparatorOptions() -> SegmentioHorizontalSeparatorOptions {
        return SegmentioHorizontalSeparatorOptions(
            type: .topAndBottom,
            height: 1,
            color: UIColor.init(r: 245, g: 245, b: 245)
        )
    }
    
    private static func segmentioVerticalSeparatorOptions() -> SegmentioVerticalSeparatorOptions {
        return SegmentioVerticalSeparatorOptions(
            ratio: 1,
            color: UIColor.clear
        )
    }
    
}
